import json, numpy as np, pandas as pd
from PIL import Image
m=json.load(open('/home/claude/work/src/in/rowimgs.json'))
# table row index r (1..46) == record id
bins={'Pembe/Magenta':(290,345),'Kırmızı':(345,15),'Turuncu/Sarı':(15,65),'Yeşil':(65,170),'Mavi/Camgöbeği':(170,260),'Mor':(260,290)}
out=[]
for r,ps in m.items():
    for p in ps:
        im=Image.open('/home/claude/work/src/in/x'+p).convert('RGB')
        if im.size[0]<100: continue
        im.thumbnail((800,800))
        a=np.asarray(im).astype(float)/255
        # white-balance: scale channels so that paper-white (bright, low-chroma pixels) becomes neutral
        mx=a.max(axis=2); mn=a.min(axis=2); sat=(mx-mn)/(mx+1e-6)
        paper=(mx>0.6)&(sat<0.25)
        ref=np.percentile(a[paper],90,axis=0) if paper.sum()>500 else np.percentile(a.reshape(-1,3),95,axis=0)
        a=np.clip(a/ref*ref.mean(),0,1)
        im=Image.fromarray((a*255).astype('uint8'))
        R,G,B=a[...,0],a[...,1],a[...,2]
        rg=R-G; yb=0.5*(R+G)-B
        M=(np.sqrt(rg.std()**2+yb.std()**2)+0.3*np.sqrt(rg.mean()**2+yb.mean()**2))*255
        hsv=np.asarray(im.convert('HSV')).astype(float)
        H=hsv[...,0]/255*360; S=hsv[...,1]/255; V=hsv[...,2]/255
        mask=(S>=0.25)&(V>=0.20)
        chroma=mask.mean()
        h=H[mask]; rec=dict(id=int(r),file=p.split('/')[-1],M=M,chromatic_share=chroma,meanS=S[mask].mean() if mask.any() else np.nan)
        for k,(lo,hi) in bins.items():
            sel=((h>=lo)|(h<hi)) if lo>hi else ((h>=lo)&(h<hi))
            rec[k]=sel.mean() if mask.any() else np.nan
        # light pink: hue 300-360 or 0-20 with low-moderate saturation and high value (pastel pink)
        lp=((H>=300)|(H<20))&(S>=0.15)&(S<0.55)&(V>=0.65)
        rec['Pastel pembe (piksel payı)']=lp.mean()
        out.append(rec)
df=pd.DataFrame(out)
d=pd.read_csv('ad_corpus_coded.csv')
agg=df.groupby('id').mean(numeric_only=True).reset_index()
agg['n_img']=df.groupby('id').size().values
agg=agg.merge(d[['id','year','period','gender','genre','format']],on='id')
agg['phase']=pd.cut(agg.year,[1996,1998,2003,2005],labels=['1997–1998','2001–2003','2004–2005'])
agg.to_csv('colour_by_record.csv',index=False)
df.to_csv('colour_by_image.csv',index=False)
print(len(df),'images',len(agg),'records')
print(agg.groupby('phase')[['M','chromatic_share','meanS','Pembe/Magenta','Mavi/Camgöbeği','Turuncu/Sarı','Pastel pembe (piksel payı)']].agg(['mean','count']).round(3).T)
print(agg.groupby('gender')[['M','Pembe/Magenta','Mavi/Camgöbeği','Pastel pembe (piksel payı)']].mean().round(3))
from scipy import stats
k=stats.kruskal(*[g.M.values for _,g in agg.groupby('phase')]); print('KW M',k)
k=stats.kruskal(*[g['Pembe/Magenta'].values for _,g in agg.groupby('phase')]); print('KW pink',k)
girl=agg[agg.gender=='Kız']; oth=agg[agg.gender!='Kız']
for c in ['Pembe/Magenta','Pastel pembe (piksel payı)','Mavi/Camgöbeği','M']:
    u=stats.mannwhitneyu(girl[c],oth[c],alternative='two-sided'); 
    r=1-2*u.statistic/(len(girl)*len(oth))
    print(c,round(girl[c].median(),3),round(oth[c].median(),3),u.pvalue, 'rank-biserial',round(-r,3))
