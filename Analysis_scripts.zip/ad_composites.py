"""Compose AD (Art Decor) page scans into multi-panel figures with a/b/c labels (Times-metric serif)."""
import json
from PIL import Image, ImageDraw, ImageFont
X='/home/claude/work/src/in/x'
m=json.load(open('/home/claude/work/src/in/rowimgs.json'))
FONT=ImageFont.truetype('/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf',84)
def page(rec,k=0):
    im=Image.open(X+m[str(rec)][k]).convert('RGB'); return im
def compose(panels,name,H=1900,gap=70,lab=True):
    ims=[]
    for p in panels:
        im=p if isinstance(p,Image.Image) else page(*p)
        w=int(im.size[0]*H/im.size[1]); ims.append(im.resize((w,H),Image.LANCZOS))
    top=120 if lab and len(ims)>1 else 0
    W=sum(i.size[0] for i in ims)+gap*(len(ims)-1)
    S=Image.new('RGB',(W,H+top),'white'); D=ImageDraw.Draw(S); x=0
    for k,im in enumerate(ims):
        S.paste(im,(x,top))
        D.rectangle([x,top,x+im.size[0]-1,top+H-1],outline='black',width=3)
        if top: D.text((x,8),'abcdef'[k],fill='black',font=FONT)
        x+=im.size[0]+gap
    out=f'/home/claude/work/src/figs/ad/{name}'
    S.save(out+'.png',dpi=(300,300)); S.save(out+'.tiff',dpi=(300,300),compression='tiff_lzw')
    print(name,S.size)
compose([(28,0),(30,0)],'fig10_named_rooms')
compose([(24,0),(25,0),(26,0)],'fig12_advertorials')
compose([(42,0),(45,0)],'fig13_gender')
compose([(32,0)],'fig15_colour_psychology',H=2400)
compose([(39,0),(41,0)],'fig16_credit')
compose([(36,0),(46,0)],'fig17_address')
