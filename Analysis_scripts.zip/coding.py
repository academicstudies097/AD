# Coded corpus of AD (Art Decor) child-room records, 1993-2005 (n=46), derived from Table 1 of the manuscript
# Textual codes: from headline/slogan (all records). Visual/paratext codes: from archived scans (records 24-46).
import json, csv
recs = [
# id, year, issue, pages, orig_type, slogan
(1,1993,"3","44,45","Düzenleme","Renkli, sevimli ve pratik iki tasarım: Çocuklara Özel"),
(2,1993,"3","46,48,50,52,54,56","Odalar ve Reklamlar","Tasarımları, malzemeleri, renkleri ve firmalarıyla çocuk odaları"),
(3,1993,"3","57","Eğitim","Görünüm danışmanı Sedef Betil: Her Rengin Bir Mesajı Var"),
(4,1993,"3","60-62","Tasarım","Mimarların senaryoları ve tercihleriyle “Bir Mekân, Dört Çizgi”"),
(5,1994,"12","82,84","Tasarım","Dar mekânlar için tasarladığımız çok işlevli ve eğlenceli “Çocuk Odası Mobilyaları”"),
(6,1994,"15","16-17","Mekânlar","Bursa’ya 18 km uzakta, Bademli’deki bahçeli evde Modern Yaklaşımlar"),
(7,1994,"16-17","37","Mekânlar","Uludağ eteklerinde modern, sade ve şık... Çekirge’de Daire"),
(8,1994,"21","44,46,48,50,52,54,56,58,60,62,64","Piyasa","Pratik, sevimli ve şık modelleriyle: Bebek ve Çocuk Mobilyaları"),
(9,1994,"21","65","Reklam","Bu Dünya Çocuklarımızın..."),
(10,1994,"21","66,68,70,72","Piyasa","Zengin renk, desen, malzeme seçenekleriyle eğitici ve eğlendirici ürünler: Çocuk odalarına özel"),
(11,1994,"21","76,77","Tasarım","Çocuklarınız için AD’den özel bir tasarım... Oyuncak Dolabı"),
(12,1995,"22","36","Mekânlar","Çiftehavuzlar’da dubleks daire: Noel’i Kutlayan Ev"),
(13,1995,"23","18,36,37,38,39","Posta, Mekânlar","İstanbul’un 2. Ulus semtinde Yannierler’in dubleksi: Tezatların Sentezi"),
(14,1995,"24","23,147","Reklam","Mobilya Reklamı"),
(15,1996,"35","49","Mekânlar","Marmara Denizi’ne ve adalara tepeden bakış: Konforlu ve Rahat"),
(16,1996,"35","92","Piyasa","Yorgun yatıp keyifli ve dinç kalkmanız için piyasanın seçenekleri: Yatak Odası Takımları"),
(17,1996,"37","148-150,152,154,156","Piyasa","Mobilyaları, titizlikle seçilen renkleri ve dinamizmleriyle... Genç Odaları"),
(18,1996,"38","39","Mekânlar","Ulus sırtlarından Boğaziçi’ne... Şeffaf Villa Katı"),
(19,1996,"40-41","36","Posta","Letto’da bebek ve çocuk mobilyaları"),
(20,1996,"40-41","36","Posta","Anne adayları ve çocuklar için her şey"),
(21,1996,"40-41","212,214,220","Piyasa","Dudullu’daki Mobilyacılar Sitesi’ni sizin için dolaştık: Modoko’dan seçtiklerimiz"),
(22,1996,"40-41","229","Reklam","Laminat Parke Reklamı"),
(23,1997,"46","48-49","Mekânlar","Salonda odaklanan yaşama mekânı: Ulus’ta dubleks"),
(24,1997,"49","86-88,90,92,94,96,98,100","Tanıtım ve Reklamlar","Sağlıklı fiziksel ve ruhsal gelişimleri için Ailenin Küçük Bireylerine"),
(25,1998,"69","100,102,104,106,108,110,112,114,116,118,120","Tanıtım ve Reklamlar","Modüler mobilya sistemleri, canlı renkler, farklı tasarımlar: Genç Odaları İçin..."),
(26,2001,"101","62-69","Tanıtım ve Reklamlar","Afacanın Renkli Odası"),
(27,2001,"101","70","Tasarım","Çocukların Özel Mekânı"),
(28,2001,"101","71","Tasarım","Sahibinin İsmiyle Özdeşleşen Oda"),
(29,2001,"101","72","Tasarım","Ece’nin Romantik Dünyası"),
(30,2001,"101","73","Tasarım","Sanem’e Pembe, Hakan’a Mavi..."),
(31,2002,"115","139","Tanıtım ve Reklamlar","İstikbal’in Yeni Konsepti “GO”"),
(32,2003,"129","70-73","Tasarım","Çocuklara Özel Dünya"),
(33,2004,"131","56-57","Tasarım","Tasarlarken çocuklaşıyorlar"),
(34,2004,"134","157","Tanıtım ve Reklamlar","Herşey minikler için"),
(35,2004,"134","160","Tanıtım ve Reklamlar","Karamela’lı Çocuk Odaları"),
(36,2004,"135","77","Tanıtım ve Reklamlar","O sizin tüm dünyanız olacak, bebeform da onun..."),
(37,2004,"135","151","Tanıtım ve Reklamlar","Boğaz’da Yaşam Sevinci"),
(38,2004,"135","184","Tanıtım ve Reklamlar","İnci Tuncel’den Gençlere Özel"),
(39,2004,"139","35","Tanıtım ve Reklamlar","Evinizin yeni gözdesi..."),
(40,2005,"143","19","Tanıtım ve Reklamlar","Genç Odası (Çilek): Peşin fiyatına 10 taksit"),
(41,2005,"144","31","Tanıtım ve Reklamlar","Çilek’ten Yılın Değiştirme Kampanyası"),
(42,2005,"146","147","Tanıtım ve Reklamlar","Genç Odası"),
(43,2005,"147","32","Tanıtım ve Reklamlar","Formula 1 Evinizden Geçecek"),
(44,2005,"147","51","Tanıtım ve Reklamlar","Genç Odası"),
(45,2005,"150","61","Tanıtım ve Reklamlar","Bizim için yarış devam ediyor..."),
(46,2005,"151","39","Tanıtım ve Reklamlar","Senin odan senin hayatın"),
]
# Harmonised genre (3 categories used in the text) + format (editorial vs paid advertising)
genre = {}
for i in [6,7,12,13,15,18,23,37]: genre[i]="Konut projesi"
for i in [1,3,4,5,11,27,28,29,30,32,33]: genre[i]="Tasarım sayfası"
for i in range(1,47): genre.setdefault(i,"Tanıtım ve reklam")
paid = {9,14,22,36,39,40,41,42,44,45,46}
fmt = {i:("Ücretli reklam" if i in paid else ("Ürün derlemesi / advertorial" if genre[i]=="Tanıtım ve reklam" else "Editoryal")) for i in range(1,47)}
age = {}
for i in [20,34,36]: age[i]="Bebek"
for i in [8,19,24,32]: age[i]="Bebek+Çocuk"
for i in [1,2,3,5,9,10,11,26,27,28,29,30,35,37,45]: age[i]="Çocuk"
for i in [17,25,31,38,39,40,42,44,46]: age[i]="Genç"
for i in [33,41,43,21]: age[i]="Çok yaşlı/0–24"
for i in range(1,47): age.setdefault(i,"Belirtilmemiş")
# Thematic codes (binary). T = textual evidence (headline/spot); V = visual/paratext evidence (scans)
TH = {
 "PED":"Pedagoji, gelişim ve sağlık",
 "FUN":"İşlevsellik, pratiklik, modülerlik",
 "AES":"Estetik ve yaşam tarzı",
 "IND":"Bireyselleşme ve kimlik",
 "MKT":"Marka, piyasa ve tüketim",
 "FAN":"Fantezi, oyun ve eğlence",
 "GEN":"Cinsiyet kodlaması",
 "EXP":"Uzman / tasarımcı otoritesi",
 "GLO":"Küreselleşme, ithalat, lisans ve standart",
 "FIN":"Finansallaşma (taksit, kredi kartı, kampanya)",
 "AGE":"Yaş segmentasyonu ve ürün yaşam döngüsü",
 "TEC":"Teknoloji ve medya nesneleri",
}
code = {k:set() for k in TH}
def add(k, ids):
    code[k].update(ids)
add("PED",[3,10,24,26,31,32,35,46])
add("FUN",[1,5,8,25,31,35,38,43,24])
add("AES",[1,2,6,7,8,10,13,15,17,25,26,29,39,40])
add("IND",[25,27,28,29,30,33,38,46,31])
add("MKT",[2,8,9,10,14,16,17,19,20,21,22,24,25,26,27,28,29,30,31,32,33,34,35,36,38,39,40,41,42,43,44,45,46])
add("FAN",[5,10,24,26,29,32,33,34,36,41,43,45])
add("GEN",[27,28,29,30,35,37,38,39,40,42,43,44,46])
add("EXP",[1,3,4,5,11,27,28,32,33,34,37])
add("GLO",[12,24,25,26,33,42,43,46])
add("FIN",[39,40,41,45])
add("AGE",[8,17,19,20,24,25,31,33,34,38,40,41,42,44,46])
add("TEC",[24,25,31,41,46])
visual = set(range(24,47))
# Indicators for Table 1 (only where a scan is archived)
ind = {
24:dict(Yatak="Beşik, ranza, araba-yatak, kaydıraklı oyun yatağı",Zemin="Halı, halıfleks, parke",Teknoloji="Bilgisayar/çalışma masası",Marka="Mothercare, M Design, Garden Life, İnci Tunçel, Letto, Pikares, Arısan, Sarıca, Popüler",Tema="Oyun parkı, yarış arabası, country",Cinsiyet="Karma (birincil renkler; pastel bebek odaları)"),
25:dict(Yatak="Modüler yatak, ranza, kanepe-yatak",Zemin="Parke, kilim",Teknoloji="Bilgisayar, motosiklet aksesuarı",Marka="Arısan (Color 4 Kids), Strongbow, Vizyon, Kelebek, Prestij (Interlübke), Iroko (Casamania), Vibel, Maltepe, Çağla Bebe, Yavuz Adıgüzel (Zalf)",Tema="Dinamik/modüler genç odası",Cinsiyet="Nötr–maskülen"),
26:dict(Yatak="Tekstil odaklı (nevresim, örtü, perde)",Zemin="Halı",Teknoloji="—",Marka="Taç (Zorlu), Vibel, Karum, Biggie Best, KA International",Tema="Lisanslı karakterler (Mickey Mouse, Pokémon, Digimon, Barbie, Winnie the Pooh, Harry Potter)",Cinsiyet="Karma; pembe/mavi seriler"),
27:dict(Yatak="Tek kişilik ahşap karyola",Zemin="Halı",Teknoloji="—",Marka="Oda Oda Collection",Tema="Romantik-klasik, çiçek desenli tekstil",Cinsiyet="Kız"),
28:dict(Yatak="Tek kişilik, kalp motifli başlık",Zemin="Parke + kilim",Teknoloji="Klima",Marka="En Mimarlık, Tepe Mobilya",Tema="İsimle kişiselleştirme",Cinsiyet="Kız (kardeş: erkek)"),
29:dict(Yatak="Patchwork örtülü karyola",Zemin="Halıfleks",Teknoloji="—",Marka="Biggie Best",Tema="Romantik dünya",Cinsiyet="Kız"),
30:dict(Yatak="Döşemeli karyola / ekose örtülü yatak",Zemin="Parke",Teknoloji="—",Marka="Biggie Best",Tema="Kardeş odalarında renk ayrımı",Cinsiyet="İkili ayrışma (pembe/mavi)"),
31:dict(Yatak="Tek kişilik genç yatağı",Zemin="Laminat + halı",Teknoloji="Bilgisayar, gitar",Marka="İstikbal (GO)",Tema="Hareketli yaşam tarzı, özgürlük",Cinsiyet="Nötr"),
32:dict(Yatak="Beşik, araba-yatak",Zemin="Parke",Teknoloji="—",Marka="Vibel (Nouvea Cradle)",Tema="Duvar resmi, tırmanma duvarı, renk psikolojisi",Cinsiyet="Karma"),
33:dict(Yatak="Cibinlikli karyola",Zemin="Parke",Teknoloji="—",Marka="Çilek",Tema="Tasarım ekibi, 7–19 yaş, ihracat",Cinsiyet="Karma"),
34:dict(Yatak="Açılır-kapanır karyola",Zemin="—",Teknoloji="—",Marka="Bebeform",Tema="Hayvan figürleri",Cinsiyet="Nötr"),
35:dict(Yatak="Tek kişilik karyola",Zemin="Seramik/açık zemin",Teknoloji="—",Marka="Karamela",Tema="Perili örtüler, dinolu yastıklar",Cinsiyet="İkili ayrışma (peri/dino)"),
36:dict(Yatak="Beşik",Zemin="—",Teknoloji="—",Marka="Bebeform",Tema="Hayvan figürleri, gülen güneş",Cinsiyet="Nötr"),
37:dict(Yatak="Asma kat (loft) yatak",Zemin="Halıfleks",Teknoloji="—",Marka="—",Tema="Çocuk katı / süit, banyo",Cinsiyet="Kız"),
38:dict(Yatak="Cibinlikli karyola",Zemin="Parke",Teknoloji="—",Marka="İnci Tuncel (Caddebostan, Levent)",Tema="Tuvalet masası, pastel",Cinsiyet="Kız"),
39:dict(Yatak="Çift kişilik genç yatağı",Zemin="Desenli halı",Teknoloji="—",Marka="Deco Halı, İstikbal; kredi kartı logoları",Tema="Genç kız, serbest zaman",Cinsiyet="Kız"),
40:dict(Yatak="Cibinlikli karyola",Zemin="—",Teknoloji="—",Marka="Çilek Genç Odası",Tema="Peşin fiyatına 10 taksit",Cinsiyet="Kız"),
41:dict(Yatak="Araba-yatak, ranza, karyola",Zemin="—",Teknoloji="Çalışma masası/bilgisayar",Marka="Çilek",Tema="Katalog ızgarası; 14 taksit; değiştirme kampanyası",Cinsiyet="Karma"),
42:dict(Yatak="Barbie lisanslı karyola",Zemin="Barbie halısı",Teknoloji="—",Marka="Çilek (Barbie)",Tema="Lisanslı karakter",Cinsiyet="Kız"),
43:dict(Yatak="Formula 1 araba-yatak (Carbed)",Zemin="Halı",Teknoloji="—",Marka="Çilek",Tema="Otomobil yarışı",Cinsiyet="Erkek"),
44:dict(Yatak="Çadırlı genç yatağı",Zemin="Bambu hasır",Teknoloji="—",Marka="Çilek Genç Odası",Tema="Macera / kamuflaj",Cinsiyet="Erkek"),
45:dict(Yatak="Formula 1 araba-yatak",Zemin="Dama desenli zemin",Teknoloji="—",Marka="Çilek",Tema="Yarış; 10 taksit",Cinsiyet="Karma (kız + yarış arabası)"),
46:dict(Yatak="Cibinlikli karyola",Zemin="Halı",Teknoloji="iPod",Marka="Çilek; AB standardı, GS, antialerjik/antikanserojen",Tema="Genç kız yaşam tarzı",Cinsiyet="Kız"),
}
gcode = {}
for i,d in ind.items():
    c=d["Cinsiyet"]
    gcode[i] = "Kız" if c.startswith("Kız") else "Erkek" if c.startswith("Erkek") else "İkili ayrışma" if c.startswith("İkili") else "Karma/Nötr"
def period(y): return "1993–1996" if y<=1996 else ("1997–2000" if y<=2000 else "2001–2005")
def npages(s):
    n=0
    for part in s.split(","):
        part=part.strip()
        if "-" in part:
            a,b=part.split("-"); n+=int(b)-int(a)+1
        else: n+=1
    return n
rows=[]
for (i,y,iss,pg,ot,sl) in recs:
    r=dict(id=i,year=y,issue=iss,pages=pg,n_pages=npages(pg),orig_type=ot,genre=genre[i],format=fmt[i],age=age[i],period=period(y),slogan=sl,visual=int(i in visual),gender=gcode.get(i,""))
    for k in TH: r[k]=int(i in code[k])
    rows.append(r)
with open('/home/claude/work/src/analysis/ad_corpus_coded.csv','w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
json.dump(dict(TH=TH,ind={str(k):v for k,v in ind.items()}),open('/home/claude/work/src/analysis/meta.json','w'),ensure_ascii=False,indent=1)
print(len(rows))
