import matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
mpl.rcParams.update({'font.family':['Times New Roman','Liberation Serif'],'font.size':8,'svg.fonttype':'none','pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(6.85,6.4)); ax.set_xlim(0,100); ax.set_ylim(8,100); ax.axis('off')
cols=[('I. Spatial absence','pre-modern household\nbefore c. 1800','#eef1f5'),('II. Pedagogical refuge','nursery → modernist room\n1850–1980 (Turkey 1930–80)','#e3eefb'),('III. Status showcase','post-1980 design media\nAD, Turkey 1993–2005','#fbe3d6')]
X=[31.5,58.5,85.5]; W=[22.5,23.5,23.5]
rows=[('Child figure',['small adult;\nto be “domesticated”','fragile, innocent pupil;\nindividual to be disciplined','consumer subject;\nnamed, gendered individual']),
('Spatial form',['shared volume; no corridors,\nno private bed','separate nursery or room;\nplan norm (3+1, 2+1)','branded, themed room;\nreplaceable by age stage']),
('Legitimizing\ndiscourse',['household order;\nadult comfort','hygiene, ventilation,\ndevelopment, character','personality, fantasy,\ncertified health, “science”']),
('Authority',['household / community','physician, child expert,\nreformist architect','brand, designer, magazine;\nlicensor']),
('Value regime',['—','use-value\n(function, hygiene)','sign-value\n(distinction, display)']),
('Addressee',['—','parents (mother)','parents → child\n(“Your room is your life”)'])]
top=97; hh=9
for (t,s,c),x,w in zip(cols,X,W):
    ax.add_patch(FancyBboxPatch((x-w/2,top-hh),w,hh,boxstyle='round,pad=0.4,rounding_size=1.6',fc=c,ec='#3b3b3b',lw=0.8))
    ax.text(x,top-2.6,t,ha='center',va='center',fontsize=9,fontweight='bold'); ax.text(x,top-6.3,s,ha='center',va='center',fontsize=7,color='#333',linespacing=1.1)
for i in range(2):
    ax.add_patch(FancyArrowPatch((X[i]+W[i]/2+0.9,top-hh/2),(X[i+1]-W[i+1]/2-0.9,top-hh/2),arrowstyle='-|>',mutation_scale=8,lw=0.8,color='#3b3b3b'))
y=top-hh-1.8; rh=7.8
for j,(lab,cells) in enumerate(rows):
    yc=y-rh/2-j*rh
    ax.text(1,yc,lab,ha='left',va='center',fontsize=7.8,fontweight='bold',color='#222')
    for k,(x,w) in enumerate(zip(X,W)):
        ax.add_patch(FancyBboxPatch((x-w/2,yc-rh/2+0.7),w,rh-1.4,boxstyle='round,pad=0.2,rounding_size=0.8',fc='white' if k<2 else '#fff6f1',ec='#c9c7c0',lw=0.6))
        ax.text(x,yc,cells[k],ha='center',va='center',fontsize=7.3,linespacing=1.1)
    ax.plot([1,99],[yc-rh/2,yc-rh/2],color='#ecebe7',lw=0.5,zorder=0)
# mechanisms band
yb=y-len(rows)*rh-2.5
mech=[('Brand, market & consumption','96%'),('Gender coding','57%'),('Age segmentation & life-cycle','48%'),('Fantasy & play','43%'),('Individualization','39%'),('Globalization, licensing & standards','30%'),('Financialization (2004–05)','29%')]
ax.add_patch(FancyBboxPatch((3,yb-21.5),94,21.5,boxstyle='round,pad=0.3,rounding_size=1.2',fc='#fbf4ef',ec='#e0a383',lw=0.8))
ax.text(5,yb-2.2,'Mechanisms of the status showcase identified in AD (share of scanned records, n = 23)',fontsize=8,fontweight='bold',va='center')
for i,(m,p) in enumerate(mech):
    cx=6+ (i%2)*46; cy=yb-6.8-(i//2)*4.3
    ax.text(cx,cy,f'{p}',fontsize=8,fontweight='bold',color='#b4471d',va='center'); ax.text(cx+6.0,cy,m,fontsize=7.4,va='center')
ax.add_patch(FancyArrowPatch((X[2],yb+0.2),(X[2],y-len(rows)*rh+0.6),arrowstyle='-|>',mutation_scale=9,lw=0.9,color='#b4471d'))
ax.text(50,yb-25.5,'Continuities reworked: hygiene → certification marketing; expert reformer → brand designer; color as character → color as gender code',ha='center',fontsize=7.3,style='italic',color='#444')
OUT='/home/claude/work/src/figs/fig12_model'
for ext in ['png','pdf','svg','tiff']:
    kw=dict(bbox_inches='tight',facecolor='white')
    if ext in('png','tiff'): kw['dpi']=600
    if ext=='tiff': kw['pil_kwargs']={'compression':'tiff_lzw'}
    fig.savefig(OUT+'.'+ext,**kw)
