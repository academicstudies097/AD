import subprocess, os, re, json
from PIL import Image
Image.MAX_IMAGE_PIXELS=None
OUT='/home/claude/work/src/outputs/HC/Figures/'
TMP='/tmp/claude-0/-home-claude/5112cbb5-81b9-50ab-af28-02b26122c967/scratchpad/'
s=open('hc/text.txt').read()
figs={int(n):p for n,p in re.findall(r'^FIG: (\d+)\|([^|]+)\|',s,re.M)}
pdfmap={7:('figs/fig7_workflow.pdf',1200,'gray'),18:('figs/fig12_model.pdf',1200,'gray'),
        8:('figs/fig8_corpus_timeline.pdf',600,'rgb'),9:('figs/fig9_theme_heatmap.pdf',600,'rgb'),
        11:('figs/fig10_cooccurrence.pdf',600,'rgb'),14:('figs/fig11_colour.pdf',600,'rgb')}
rep=[]
for n,p in sorted(figs.items()):
    if n in pdfmap:
        pdf,dpi,mode=pdfmap[n]; base=TMP+f'f{n}'
        subprocess.run(['pdftoppm','-r',str(dpi),'-singlefile','-png']+(['-gray'] if mode=='gray' else [])+[pdf,base],check=True)
        im=Image.open(base+'.png'); im=im.convert('L' if mode=='gray' else 'RGB')
        fn=f'Figure{n}.tif'; im.save(OUT+fn,compression='tiff_lzw',dpi=(dpi,dpi))
        rep.append((n,fn,im.size,dpi,'line art (B&W)' if mode=='gray' else 'color chart'))
    elif '/figs/ad/' in p:
        src=p.replace('.jpg','.png'); im=Image.open(src).convert('RGB')
        fn=f'Figure{n}.jpg'; im.save(OUT+fn,quality=95,dpi=(300,300)); rep.append((n,fn,im.size,300,'color halftone (AD page scans)'))
    else:
        im=Image.open(p); gray = n in (4,5,6)
        im=im.convert('L' if gray else 'RGB')
        if gray: fn=f'Figure{n}.tif'; im.save(OUT+fn,compression='tiff_lzw',dpi=(300,300))
        else: fn=f'Figure{n}.jpg'; im.save(OUT+fn,quality=95,dpi=(300,300))
        rep.append((n,fn,im.size,None,'grayscale (source scan)' if gray else 'color (source image)'))
for r in rep:
    n,fn,(w,h),dpi,kind=r; sz=os.path.getsize(OUT+fn)/1e6
    print(n,fn,w,h,kind,f'{sz:.1f}MB', f'max print width at 300 dpi: {w/300:.1f} in' )
json.dump(rep,open('hc/figreport.json','w'))
