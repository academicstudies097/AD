import pandas as pd, numpy as np, json, matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.patches import Patch
from scipy import stats
mpl.rcParams.update({'font.family':['Times New Roman','Liberation Serif'],'font.size':8.5,'svg.fonttype':'none','mathtext.fontset':'stix','axes.titlesize':9,'axes.labelsize':8,
 'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':0.6,'xtick.major.width':0.6,'ytick.major.width':0.6,
 'xtick.major.size':2.5,'ytick.major.size':2.5,'axes.edgecolor':'#52514e','xtick.color':'#52514e','ytick.color':'#52514e',
 'axes.labelcolor':'#0b0b0b','text.color':'#0b0b0b','savefig.dpi':600,'pdf.fonttype':42,'legend.frameon':False})
OUT='/home/claude/work/src/figs/'
C={'blue':'#2a78d6','orange':'#eb6834','aqua':'#1baf7a','yellow':'#eda100','magenta':'#e87ba4','green':'#008300','violet':'#6250d6','red':'#e34948'}
INK2='#52514e'; GRID='#e6e5e1'
d=pd.read_csv('ad_corpus_coded.csv'); meta=json.load(open('meta.json'))
TH={"PED":"Pedagogy, development & health","FUN":"Functionality & modularity","AES":"Aesthetics & lifestyle","IND":"Individualization & identity","MKT":"Brand, market & consumption","FAN":"Fantasy, play & entertainment","GEN":"Gender coding","EXP":"Expert / designer authority","GLO":"Globalization, licensing & standards","FIN":"Financialization (instalments, credit)","AGE":"Age segmentation & life-cycle","TEC":"Technology & media objects"}
def save(fig,name):
    fig.savefig(OUT+name+'.png',dpi=600,bbox_inches='tight',facecolor='white')
    fig.savefig(OUT+name+'.pdf',bbox_inches='tight',facecolor='white')
    fig.savefig(OUT+name+'.svg',bbox_inches='tight',facecolor='white')
    fig.savefig(OUT+name+'.tiff',dpi=600,bbox_inches='tight',facecolor='white',pil_kwargs={'compression':'tiff_lzw'})
    plt.close(fig)
def lab(ax,s): ax.text(-0.02,1.06,s,transform=ax.transAxes,fontsize=10,fontweight='bold',va='bottom',ha='right')
# ---------- FIG 8 corpus timeline + index context (2x2)
years=list(range(1993,2006)); G=['Tasarım sayfası','Konut projesi','Tanıtım ve reklam']; gc=[C['blue'],C['aqua'],C['orange']]
GEN_EN={'Tasarım sayfası':'Design page','Konut projesi':'House feature','Tanıtım ve reklam':'Promotion & advertising'}
ct=pd.crosstab(d.year,d.genre).reindex(years,fill_value=0)[G]
fig,axs=plt.subplots(2,2,figsize=(6.85,5.0),gridspec_kw={'hspace':0.62,'wspace':0.28})
def yr_axis(ax):
    ax.set_xticks(years); ax.set_xticklabels([f"'{str(y)[2:]}" for y in years]); ax.set_xlim(1992.4,2005.6)
ax=axs[0,0]; bottom=np.zeros(len(years))
for g,c in zip(G,gc):
    ax.bar(years,ct[g],bottom=bottom,color=c,width=0.66,label=GEN_EN[g],edgecolor='white',linewidth=0.8); bottom+=ct[g].values
for x,v in zip(years,bottom):
    if v>0: ax.text(x,v+0.2,int(v),ha='center',va='bottom',fontsize=6.5,color=INK2)
ax.set_ylabel('Records (n)'); ax.set_ylim(0,11); ax.yaxis.grid(True,color=GRID,lw=0.5); ax.set_axisbelow(True); yr_axis(ax)
ax.legend(ncol=1,loc='upper right',fontsize=6.5,handlelength=0.9,bbox_to_anchor=(1.0,1.02)); lab(ax,'a')
ax.set_title('Record inventory: records by genre',fontsize=8,loc='left',pad=4)
ax=axs[0,1]
F=['Editoryal','Ürün derlemesi / advertorial','Ücretli reklam']; fc=[C['blue'],C['yellow'],C['red']]
F_EN={'Editoryal':'Editorial','Ürün derlemesi / advertorial':'Product round-up','Ücretli reklam':'Paid advertisement'}
pgf=d.pivot_table(index='year',columns='format',values='n_pages',aggfunc='sum').reindex(years,fill_value=0).fillna(0)
bottom=np.zeros(len(years))
for f,c in zip(F,fc):
    v=pgf[f].values if f in pgf else np.zeros(len(years))
    ax.bar(years,v,bottom=bottom,color=c,width=0.66,label=F_EN[f],edgecolor='white',linewidth=0.8); bottom+=v
ax.set_ylabel('Pages (n)'); ax.yaxis.grid(True,color=GRID,lw=0.5); ax.set_axisbelow(True); ax.set_ylim(0,32); yr_axis(ax)
ax.legend(ncol=1,loc='upper right',fontsize=6.5,handlelength=0.9); lab(ax,'b')
ax.set_title('Record inventory: pages by editorial format',fontsize=8,loc='left',pad=4)
R=pd.read_pickle('/home/claude/work/src/in2/issues2.pkl'); T_=R[R.has_text]
by=T_.groupby('year_i').agg(n=('issue','size'),child=('child','mean'),teen=('teen','mean')).reindex(years)
ax=axs[1,0]; w=0.36
ax.bar(np.array(years)-w/2,by.child*100,width=w,color=C['blue'],label='Child or teen room')
ax.bar(np.array(years)+w/2,by.teen*100,width=w,color=C['magenta'],label='Teen room')
for y,(n,cv) in by[['n','child']].iterrows():
    if pd.notna(n): ax.text(y,(cv*100 if pd.notna(cv) else 0)+3,f"{int(n)}",ha='center',fontsize=6,color=INK2)
    else: ax.text(y,3,'n.i.',ha='center',fontsize=6,color=INK2,rotation=90)
ax.set_ylabel('Indexed issues with content (%)'); ax.set_ylim(0,105); ax.yaxis.grid(True,color=GRID,lw=0.5); ax.set_axisbelow(True); yr_axis(ax)
ax.legend(loc='upper left',fontsize=6.5,handlelength=0.9); lab(ax,'c')
ax.set_title('Issue index: child- and teen-room content',fontsize=8,loc='left',pad=4)
ax=axs[1,1]
pp=R.dropna(subset=['pages']).copy(); pp['pages']=pp.pages.astype(float)
py=pp.groupby('year_i').pages.agg(['mean','min','max']).reindex(years)
ax.axvspan(2000.5,2001.5,color='#f2f1ee',zorder=0); ax.text(2001,252,'2001\ncrisis',ha='center',va='top',fontsize=6,color=INK2,style='italic')
ok=py['mean'].notna()
ax.vlines(np.array(years)[ok],py['min'][ok],py['max'][ok],color='#b9b8b2',lw=1.2,zorder=1)
yy=np.array(years); mm=py['mean'].values
seg=[]; cur=[]
for y_,m_ in zip(yy,mm):
    if np.isnan(m_):
        if cur: seg.append(cur); cur=[]
    else: cur.append((y_,m_))
if cur: seg.append(cur)
for sg in seg:
    ax.plot([p[0] for p in sg],[p[1] for p in sg],color=C['blue'],lw=1.5,marker='o',ms=4,mec='white',mew=0.8,zorder=3)
ax.text(1995.5,112,'not indexed',ha='center',fontsize=6,color=INK2,style='italic')
ax.set_ylabel('Pages per issue'); ax.set_ylim(100,265); ax.yaxis.grid(True,color=GRID,lw=0.5); ax.set_axisbelow(True); yr_axis(ax)
lab(ax,'d'); ax.set_title('Issue index: magazine size (mean, range)',fontsize=8,loc='left',pad=4)
save(fig,'fig8_corpus_timeline')
# ---------- headline-only codes (layer T)
T = {"PED":[3,10,24],"FUN":[1,5,8,25],"AES":[1,2,6,7,8,10,13,15,17,25,26,29,39],"IND":[28,29,30,46],
 "MKT":[2,9,14,16,19,21,22,31,35,36,38,40,41],"FAN":[5,10,26,29,32,43,45],"GEN":[30],"EXP":[3,4,5,11,33],
 "GLO":[12,43],"FIN":[40,41],"AGE":[8,17,19,20,24,25,34,38,40,42,44],"TEC":[]}
for k,v in T.items(): d['T_'+k]=d.id.isin(v).astype(int)
order=['MKT','AES','AGE','FAN','EXP','IND','FUN','PED','GEN','GLO','FIN','TEC']
P=['1993–1996','1997–2000','2001–2005']
rowsT=[];rowsF=[]
early=d[d.period=='1993–1996']; late=d[d.period=='2001–2005']
for k in order:
    a=int(early['T_'+k].sum()); b=len(early)-a; c_=int(late['T_'+k].sum()); dd=len(late)-c_
    pT=stats.fisher_exact([[a,b],[c_,dd]])[1]
    a2=int(early[k].sum()); c2=int(late[k].sum())
    pF=stats.fisher_exact([[a2,len(early)-a2],[c2,len(late)-c2]])[1]
    rowsT.append(dict(code=k,label=TH[k],**{f'T {p}':d[d.period==p]['T_'+k].mean() for p in P},
        **{f'F {p}':d[d.period==p][k].mean() for p in P},
        nT=int(d['T_'+k].sum()),nF=int(d[k].sum()),pT=pT,pF=pF,
        T_early=a,T_late=c_,F_early=a2,F_late=c2))
res=pd.DataFrame(rowsT); res.to_csv('theme_period_stats.csv',index=False)
print(res[['code','nT','T_early','T_late','pT','nF','F_early','F_late','pF']].round(4).to_string())
# visual subset prevalence by phase
v=d[d.visual==1].copy(); v['phase']=pd.cut(v.year,[1996,1998,2003,2005],labels=['1997–1998','2001–2003','2004–2005'])
VP=['1997–1998','2001–2003','2004–2005']
# ---------- FIG 9 heatmaps
from matplotlib.colors import LinearSegmentedColormap
cmap=LinearSegmentedColormap.from_list('b',['#f7fbff','#cde2fb','#86b6ef','#3987e5','#1c5cab','#0d366b'])
fig,axs=plt.subplots(1,2,figsize=(6.85,3.9),gridspec_kw={'width_ratios':[1,1],'wspace':0.08})
labels=[TH[k] for k in order]
M1=np.array([[d[d.period==p]['T_'+k].mean()*100 for p in P] for k in order])
M2=np.array([[v[v.phase==p][k].mean()*100 for p in VP] for k in order])
nP=[len(d[d.period==p]) for p in P]; nV=[len(v[v.phase==p]) for p in VP]
for ax,M,cols,ns,ttl,letter in [(axs[0],M1,P,nP,'Headline layer (all records, n = 46)','a'),(axs[1],M2,VP,nV,'Visuo-textual layer (archived scans, n = 23)','b')]:
    im=ax.imshow(M,cmap=cmap,vmin=0,vmax=100,aspect='auto')
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            val=M[i,j]; ax.text(j,i,f'{val:.0f}',ha='center',va='center',fontsize=7,color='white' if val>55 else '#0b0b0b')
    ax.set_xticks(range(len(cols))); ax.set_xticklabels([f'{c}\n(n = {n})' for c,n in zip(cols,ns)],fontsize=7.5)
    ax.xaxis.tick_top(); ax.tick_params(length=0)
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_xticks(np.arange(-.5,len(cols),1),minor=True); ax.set_yticks(np.arange(-.5,len(order),1),minor=True)
    ax.grid(which='minor',color='white',lw=1.5); ax.tick_params(which='minor',length=0)
    ax.set_title(ttl,fontsize=8,pad=26,loc='left'); ax.text(-0.02,1.13,letter,transform=ax.transAxes,fontsize=10,fontweight='bold',ha='right')
axs[0].set_yticks(range(len(order))); axs[0].set_yticklabels(labels,fontsize=7.5)
axs[1].set_yticks(range(len(order))); axs[1].set_yticklabels([])
cb=fig.colorbar(im,ax=axs,fraction=0.025,pad=0.02); cb.set_label('Records containing the theme (%)',fontsize=7.5); cb.outline.set_visible(False); cb.ax.tick_params(labelsize=7)
save(fig,'fig9_theme_heatmap')
# ---------- FIG 10 co-occurrence matrix (Jaccard, full coding)
from scipy.cluster.hierarchy import linkage, leaves_list
X=d[order].values.astype(bool); nn_=X.sum(0); K_=len(order)
J=np.zeros((K_,K_)); CNT=np.zeros((K_,K_),int)
for i in range(K_):
    for j in range(K_):
        inter=(X[:,i]&X[:,j]).sum(); uni=(X[:,i]|X[:,j]).sum(); J[i,j]=inter/uni if uni else 0; CNT[i,j]=inter
Z=linkage(1-J[np.triu_indices(K_,1)],'average'); lv=leaves_list(Z)
J=J[np.ix_(lv,lv)]; CNT=CNT[np.ix_(lv,lv)]; ordc=[order[i] for i in lv]
fig,ax=plt.subplots(figsize=(6.2,5.2))
Mk=np.where(np.tril(np.ones_like(J),-1)==1,J,np.nan)
im=ax.imshow(Mk,cmap=cmap,vmin=0,vmax=0.6)
for i in range(K_):
    for j in range(i):
        if CNT[i,j]>0:
            ax.text(j,i,f"{J[i,j]:.2f}\n({CNT[i,j]})",ha='center',va='center',fontsize=6,color='white' if J[i,j]>0.33 else '#0b0b0b',linespacing=0.95)
lbl=[f"{TH[k]} ({int(d[k].sum())})" for k in ordc]
ax.set_yticks(range(1,K_)); ax.set_yticklabels(lbl[1:],fontsize=7.5)
ax.set_xticks(range(K_-1)); ax.set_xticklabels(lbl[:-1],fontsize=7.5,rotation=50,ha='right',rotation_mode='anchor')
ax.set_xlim(-0.5,K_-1.5); ax.set_ylim(K_-0.5,0.5)
for sp in ax.spines.values(): sp.set_visible(False)
ax.tick_params(length=0)
ax.set_xticks(np.arange(-.5,K_,1),minor=True); ax.set_yticks(np.arange(-.5,K_,1),minor=True); ax.grid(which='minor',color='white',lw=1.4); ax.tick_params(which='minor',length=0)
cb=fig.colorbar(im,ax=ax,fraction=0.035,pad=0.02); cb.set_label('Jaccard similarity (co-occurring records in brackets)',fontsize=7.5); cb.outline.set_visible(False); cb.ax.tick_params(labelsize=7)
save(fig,'fig10_cooccurrence')
# ---------- FIG 11 colour
col=pd.read_csv('colour_by_record.csv'); img=pd.read_csv('colour_by_image.csv')
hues=['Pembe/Magenta','Kırmızı','Turuncu/Sarı','Yeşil','Mavi/Camgöbeği','Mor']
HUE_EN={'Pembe/Magenta':'Pink/magenta','Kırmızı':'Red','Turuncu/Sarı':'Orange/yellow','Yeşil':'Green','Mavi/Camgöbeği':'Blue/cyan','Mor':'Violet'}
GD_EN={'Kız':'Girl-coded','Erkek':'Boy-coded','İkili ayrışma':'Binary pairing','Karma/Nötr':'Mixed/neutral'}
hc=['#e87ba4','#e34948','#eda100','#1baf7a','#2a78d6','#6250d6']
ph=['1997–1998','2001–2003','2004–2005']
fig=plt.figure(figsize=(6.85,5.2)); gs=fig.add_gridspec(2,2,height_ratios=[1,1.05],hspace=0.75,wspace=0.32)
ax=fig.add_subplot(gs[0,0]); comp=col.groupby('phase')[hues].mean().reindex(ph); comp=comp.div(comp.sum(1),axis=0)*100
left=np.zeros(3)
for h,c in zip(hues,hc):
    ax.barh(range(3),comp[h],left=left,color=c,height=0.6,edgecolor='white',linewidth=1.2,label=HUE_EN[h])
    for i,(l,w) in enumerate(zip(left,comp[h])):
        if w>=7: ax.text(l+w/2,i,f'{w:.0f}',ha='center',va='center',fontsize=6.5,color='white' if h not in ['Turuncu/Sarı','Pembe/Magenta'] else '#0b0b0b')
    left+=comp[h].values
nn=col.groupby('phase').size().reindex(ph)
ax.set_yticks(range(3)); ax.set_yticklabels([f'{p} (n = {nn[p]})' for p in ph]); ax.invert_yaxis(); ax.set_xlim(0,100)
ax.set_xlabel('Share of chromatic pixels by hue family (%)'); ax.legend(ncol=3,fontsize=7,loc='upper left',bbox_to_anchor=(-0.02,-0.28),handlelength=0.9,columnspacing=0.8); lab(ax,'a')
ax=fig.add_subplot(gs[0,1])
gmap={'Kız':C['magenta'],'Erkek':C['blue'],'İkili ayrışma':C['violet'],'Karma/Nötr':'#9a9890'}
mk={'Kız':'o','Erkek':'s','İkili ayrışma':'D','Karma/Nötr':'^'}
rng=np.random.default_rng(3)
for g,c in gmap.items():
    s=col[col.gender==g]; ax.scatter(s.year+rng.uniform(-0.18,0.18,len(s)),s['Pembe/Magenta']*100,s=22,color=c,marker=mk[g],edgecolor='white',linewidth=0.6,label=f'{GD_EN[g]} (n = {len(s)})',zorder=3)
ax.set_xlabel('Year'); ax.set_ylabel('Pink/magenta share of chromatic pixels (%)'); ax.set_xticks([1997,1999,2001,2003,2005]); ax.yaxis.grid(True,color=GRID,lw=0.5); ax.set_axisbelow(True)
ax.legend(fontsize=6.5,loc='upper left',handletextpad=0.3); lab(ax,'b')
kw=stats.kruskal(*[g['Pembe/Magenta'].values for _,g in col.groupby('phase')])
ax.text(0.03,0.52,f'Kruskal–Wallis (three phases)\n$H$ = {kw.statistic:.2f}, $p$ = {kw.pvalue:.3f}',transform=ax.transAxes,ha='left',va='top',fontsize=7,color=INK2)
# panel c: dominant palettes per record via k-means
from PIL import Image
from scipy.cluster.vq import kmeans2
m=json.load(open('/home/claude/work/src/in/rowimgs.json'))
ax=fig.add_subplot(gs[1,:]); recs=col.sort_values(['year','id'])
K=6
for j,(_,r) in enumerate(recs.iterrows()):
    pix=[]
    for p in m[str(int(r.id))]:
        im=Image.open('/home/claude/work/src/in/x'+p).convert('RGB')
        if im.size[0]<100: continue
        im.thumbnail((200,200)); a=np.asarray(im.convert('HSV')).reshape(-1,3).astype(float); rgb=np.asarray(im).reshape(-1,3).astype(float)
        msk=(a[:,1]>=64)&(a[:,2]>=51); pix.append(rgb[msk])
    pix=np.vstack(pix)
    cent,labl=kmeans2(pix,K,seed=1,minit='++'); cnt=np.bincount(labl,minlength=K)
    o=np.argsort(-cnt); cum=0
    for k in o:
        h=cnt[k]/cnt.sum(); ax.add_patch(plt.Rectangle((j,cum),0.86,h,color=np.clip(cent[k]/255,0,1),lw=0)); cum+=h
ax.set_xlim(-0.3,len(recs)); ax.set_ylim(0,1)
ax.set_xticks(np.arange(len(recs))+0.43); ax.set_xticklabels([f'{int(r.id)}\n{str(int(r.year))[2:]}' for _,r in recs.iterrows()],fontsize=6)
ax.set_yticks([0,0.5,1]); ax.set_yticklabels(['0','50','100']); ax.set_ylabel('Share of dominant color (%)')
ax.set_xlabel("Record no. / year ('97–'05); each column is the chromatic palette of one record extracted by k-means (k = 6)")
for s in ['left','bottom']: ax.spines[s].set_visible(False)
ax.tick_params(length=0); lab(ax,'c')
save(fig,'fig11_colour')
print('figs done')
