import pandas as pd, matplotlib as mpl, matplotlib.pyplot as plt, numpy as np
mpl.rcParams.update({'font.family':['Times New Roman','Liberation Serif'],'font.size':8.5,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':0.6,'svg.fonttype':'none','pdf.fonttype':42,'axes.edgecolor':'#52514e','xtick.color':'#52514e','ytick.color':'#52514e','legend.frameon':False})
s=pd.read_csv('/home/claude/work/src/bench/sources.tsv',sep='\t')
t={l.split()[1]:int(l.split()[3]) for l in open('/home/claude/work/src/bench/turkey_counts.txt')}
s['turkey']=s.short.map(t); s['pct']=s.turkey/s.works*100
ch={'HC':17,'JDH':19,'DC':3,'JID':13,'DI':10,'INT':2,'JMC':11,'JA':9,'SC':13}
q={'HC':'Q1','JDH':'Q1','DC':'Q1','DI':'Q3','JID':'Q1','INT':'Q2','JA':'Q1','SC':'—','JMC':'Q1','JCC':'Q1','GPC':'—','JFH':'Q2','CH':'Q1','CG':'Q1','JHCY':'—'}
grp={'design-home':('Tasarım / ev kültürü','#2a78d6'),'architecture-interior':('Mimarlık / iç mimarlık','#1baf7a'),'culture-society':('Maddi / tüketim kültürü, toplum','#eb6834'),'childhood-family':('Çocukluk / aile','#e87ba4')}
s=s.sort_values('pct')
fig,axs=plt.subplots(1,2,figsize=(6.85,4.0),gridspec_kw={'width_ratios':[1.25,1],'wspace':0.55})
ax=axs[0]
for i,(_,r) in enumerate(s.iterrows()):
    ax.barh(i,r.pct,color=grp[r.group][1],height=0.62)
    ax.text(r.pct+0.05,i,f"{r.turkey}/{r.works:,}".replace(',','.')+f"  [{q[r.short]}]",va='center',fontsize=6.8,color='#333')
ax.set_yticks(range(len(s))); ax.set_yticklabels(s.journal,fontsize=7.2); ax.set_xlim(0,4.4)
ax.set_xlabel('Başlık/özette “Turkey” geçen çalışmaların payı (%)'); ax.xaxis.grid(True,color='#e6e5e1',lw=0.5); ax.set_axisbelow(True)
from matplotlib.patches import Patch
fig.legend(handles=[Patch(color=c,label=l) for l,c in grp.values()],fontsize=7.2,loc='lower center',ncol=4,bbox_to_anchor=(0.5,-0.06),handlelength=1)
ax.text(-0.02,1.03,'a',transform=ax.transAxes,fontsize=10,fontweight='bold',ha='right')
ax=axs[1]
c=s[s.short.isin(ch)].copy(); c['n']=c.short.map(ch); c=c.sort_values('n')
for i,(_,r) in enumerate(c.iterrows()):
    ax.barh(i,r.n,color=grp[r.group][1],height=0.62); ax.text(r.n+0.3,i,str(r.n),va='center',fontsize=7)
ax.set_yticks(range(len(c))); ax.set_yticklabels(c.journal,fontsize=7.2); ax.set_xlabel('Başlık/özette “children” geçen çalışma sayısı'); ax.set_xlim(0,23)
ax.xaxis.grid(True,color='#e6e5e1',lw=0.5); ax.set_axisbelow(True)
ax.text(-0.02,1.03,'b',transform=ax.transAxes,fontsize=10,fontweight='bold',ha='right')
for ext in ['png','pdf','svg']:
    fig.savefig('/home/claude/work/src/figs/figS1_benchmark.'+ext,dpi=600,bbox_inches='tight',facecolor='white')
s.to_csv('/home/claude/work/src/bench/benchmark_summary.csv',index=False)
print(s[['short','works','turkey','pct']].round(2).to_string())
